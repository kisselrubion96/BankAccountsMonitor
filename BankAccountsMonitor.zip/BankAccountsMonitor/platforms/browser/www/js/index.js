document.addEventListener("deviceready",on_device_ready,false);

function on_device_ready()
{

	var accounts = ["BDO","Metrobank"];     
	var sel = document.getElementById('accountsList');
    for(var i = 0; i < accounts.length; i++) 
    {
		var opt = document.createElement('option');
		opt.innerHTML = accounts[i];
		opt.value = accounts[i];
		sel.appendChild(opt);
    }
    document.getElementById("accountTab").setAttribute("style","display:none");
}
function on_add_account()
{
    
	document.getElementById("newTab").setAttribute("style","display:none")
	document.getElementById("accountTab").setAttribute("style","display:block")
} 
function on_save_added_account()
{
    document.getElementById("newTab").setAttribute("style","display:block")
    document.getElementById("accountTab").setAttribute("style","display:none")
    
    var addedaccount = document.getElementById('addAccountInput');
    var addedamount = document.getElementById('addAmountInput');
    accounts.push("addedaccount");
    for (var index = 0; index < accounts.length; index++) 
    {
        var opt = document.createElement('option');
		opt.innerHTML = accounts[i];
		opt.value = accounts[i];
		sel.appendChild(opt);  
    }


}